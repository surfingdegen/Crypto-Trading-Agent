"""
Crypto Trading Agent package.
This package contains modules for managing blockchain wallets,
performing technical and sentiment analysis, and executing trading strategies.
"""

__version__ = '0.1.0'
