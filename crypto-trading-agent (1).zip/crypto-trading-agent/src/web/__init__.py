"""
Web interface module for the cryptocurrency trading agent.
This module provides a web-based UI for monitoring and controlling the trading agent.
"""

__version__ = '0.1.0'
